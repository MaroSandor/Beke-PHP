<!DOCTYPE html>

<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <?php
        // Fájl elérés megadása és megnyitási mód
        //print_r($_SERVER);
        $gyoker = $_SERVER['DOCUMENT_ROOT'];
        $projekt = 'fajl_2022_1';
        $forras = 'adatok.txt';

        $fajl_eleres = "$gyoker/$projekt/$forras";

        echo $fajl_eleres . "<hr>";

        // file tartalmának beolvasása  tömbbe
        // 1 verzió
        $adatsorok = file($fajl_eleres);
        print_r($adatsorok);
        echo "<hr>";
        //1.2 verzio
        $adatsorok = file('adatok.txt');
        print_r($adatsorok);
        echo "<hr>";

        //2.verzió
        //fájlkezelő fájl megnyitása
        $file_handler = fopen("kozos/adatok2.txt", 'rw');
        $adatsorok2 = [];
        $szamlalo = 0;
        //filevégéig sorok beolvasása
        while (!feof($file_handler)) {
            $adatsorok2[$szamlalo] = fgets($file_handler);
            $szamlalo++;
        }

        print_r($adatsorok2);
        echo"<hr>";
        // fájl lezárása
        fclose($file_handler);
        ?>
    </body>
</html>
