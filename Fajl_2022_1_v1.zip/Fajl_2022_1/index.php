<!DOCTYPE html>
<?php
// Fájl elérés megadása és megnyitási mód
//print_r($_SERVER);
$gyoker = $_SERVER['DOCUMENT_ROOT'];
$projekt = 'fajl_2022_1';
$forras = 'adatok.txt';

$fajl_eleres = "$gyoker/$projekt/$forras";

//echo $fajl_eleres . "<hr>";
// file tartalmának beolvasása  tömbbe
// 1 verzió
/*  $adatsorok = file($fajl_eleres);
  print_r($adatsorok);
  echo "<hr>"; */
//1.2 verzio
$adatsorok = file('adatok.txt');
//print_r($adatsorok);
echo "<hr>";

foreach ($adatsorok as $sor) {
    $elemek = explode(',', $sor);
    //print_r($elemek);
}


foreach ($adatsorok as $index => $sor) {
    $elemek2[$index] = explode(',', $sor);
}


print_r($elemek2);
echo "<hr>";
//2.verzió
//fájlkezelő fájl megnyitása
/* $file_handler = fopen("kozos/adatok2.txt", 'rw');
  $adatsorok2 = [];
  $szamlalo = 0;
  //filevégéig sorok beolvasása
  while (!feof($file_handler)) {
  $adatsorok2[$szamlalo] = fgets($file_handler);
  $szamlalo++;
  }

  print_r($adatsorok2);
  echo"<hr>";
  // fájl lezárása
  fclose($file_handler); */
?>
<html>
    <head>
        <meta charset = "UTF-8">
        <title> Fájkezelés példák </title>
        <link href="kozos/bootstrap.min.css" rel="stylesheet" type="text/css"/>
    </head>
    <body>
        <div class="container">
            <table class="table table-success table-striped w-50">
                <?php foreach ($elemek2 as $sor) : ?>
                    <tr>
                        <?php foreach ($sor as $elem) : ?>
                            <td>
                                <?= $elem ?>
                            </td>
                        <?php endforeach; ?>
                    </tr>
                <?php endforeach; ?>
            </table>
        </div>

        <script src="kozos/bootstrap.min.js" type="text/javascript"></script>
    </body>
</html>
